
function calculateSum() {
    let sum = 0;
    let input1 = document.getElementsByClassName('taskDuration1');
    let input2 = document.getElementsByClassName('taskDuration2');
    let select1 = document.getElementsByClassName('opciones1');
    let select2 = document.getElementsByClassName('opciones2'); 
    const inputValue1 = parseInt(input1[0].value);
    const inputValue2 = parseInt(input2[0].value);
    const selectValue1 = select1[0].value;
    const selectValue2 = select2[0].value;
    if (selectValue1 === "minutos") {
        sum += inputValue1;
    } else if (selectValue1 === "horas") {
        sum += inputValue1 * 60;
    }
    if (selectValue2 === "minutos") {
        sum += inputValue2;
    } else if (selectValue2 === "horas") {
        sum += inputValue2 * 60;
    }
    document.getElementById('tiempociclo').textContent = 'Tiempo por ciclo: ' + sum + ' minutos';
}

function calculatetotal(){
    let sum = 0;
    let input1 = document.getElementsByClassName('taskDuration1');
    let input2 = document.getElementsByClassName('taskDuration2');
    let select1 = document.getElementsByClassName('opciones1');
    let select2 = document.getElementsByClassName('opciones2'); 
    const inputValue1 = parseInt(input1[0].value);
    const inputValue2 = parseInt(input2[0].value);
    const selectValue1 = select1[0].value;
    const selectValue2 = select2[0].value;
    if (selectValue1 === "minutos") {
        sum += inputValue1;
    } else if (selectValue1 === "horas") {
        sum += inputValue1 * 60;
    }
    if (selectValue2 === "minutos") {
        sum += inputValue2;
    } else if (selectValue2 === "horas") {
        sum += inputValue2 * 60;
    }
    const totalCiclos = parseInt(ciclos[0].value);
    sum=sum*totalCiclos;
    document.getElementById('tiempototal').textContent = 'Tiempo total: ' + sum + ' minutos'; 
}

// Run the calculateSum and calculatetotal functions every second
setInterval(() => {
    calculateSum();
    calculatetotal();
}, 1000);

// Add event listeners to the input elements
let inputs = document.querySelectorAll('.taskDuration');

for (let i = 0; i < inputs.length; i++) {
    inputs[i].addEventListener('input', calculateSum);
}

let ciclos = document.getElementsByClassName('ciclos');
for (let i = 0; i < ciclos.length; i++) {
    ciclos[i].addEventListener('input', calculateSum);
}

const botonE = document.getElementById('crearpomodoro');
var aktivo = false;

var i;
botonE.addEventListener('click', () => {
    alert("¡Vamos alla!");
    let input1 = document.getElementsByClassName('taskDuration1');
    let input2 = document.getElementsByClassName('taskDuration2');
    const totalCiclos = parseInt(ciclos[0].value);
    for(i=0; i<totalCiclos;  i++){
        document.getElementById('numciclos').textContent = 'Ciclo: ' + i;
        Empezar()
        function Empezar(){
            if(aktivo==false){
                aktivo=true;
                
                // Agregar los valores a la lista
                const taskDuration = parseInt(input1[0].value);
                const countDownDate = new Date().getTime() + (taskDuration * 60 * 1000);
            
                // Actualizar el contador cada segundo
                var x = setInterval(function() {
                    const now = new Date().getTime(); // Update the current time on each iteration
            
                    // Calcular la diferencia entre la fecha de vencimiento y la fecha actual
                    var distance = countDownDate - now;
                    // Calcular los días, horas, minutos y segundos restantess
                    var minutes = Math.floor(distance / (1000 * 60));
                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
                    // Mostrar el resultado en el elemento con id="countdown"
                    document.getElementById("countdown").innerHTML = minutes + "m " + seconds + "s ";
            
                    // Si la cuenta regresiva ha terminado, mostrar un mensaje y comenzar el temporizador de descanso
                    if (distance < 0) {
                        clearInterval(x);
                        document.getElementById("countdown").innerHTML = "EXPIRED";
                        startBreakTimer(); // Llamar a la función para iniciar el temporizador de descanso
                        alert("¡El temporizador ha expirado! ¡Es hora de tomar un descanso!");
                    }
                }, 1000);
            }

        
        // Función para iniciar el temporizador de descanso
        function startBreakTimer() {
            // Aquí puedes agregar el código para el temporizador de descanso
            // Por ejemplo
            const duracion = parseInt(input2[0].value);
            const breakCountDownDate = new Date().getTime() + (duracion * 60 * 1000);

            var y = setInterval(function() {
                const now = new Date().getTime(); // Update the current time on each iteration

                // Calcular la diferencia entre la fecha de vencimiento y la fecha actual
                var distance = breakCountDownDate - now;

                // Calcular los días, horas, minutos y segundos restantes
                var minutes = Math.floor(distance / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                // Mostrar el resultado en el elemento con id="breakCountdown"
                document.getElementById("breakCountdown").innerHTML = minutes + "m " + seconds + "s ";

                // Si la cuenta regresiva ha terminado, mostrar un mensaje
                if (distance < 0) {
                    clearInterval(y);
                    document.getElementById("breakCountdown").innerHTML = "BREAK EXPIRED";
                    aktivo = false;
                    alert("¡Se acabo el descanso! ¡Vamos con el siguiente ciclo!");
                    Empezar();
                }
            }, 1000);
        }
        }
    }
});
window.addEventListener('beforeunload', function (e) {
    // Cancelar el evento
    e.preventDefault();
    // Chrome requiere que se establezca returnValue
    e.returnValue = '';
});
