document.querySelector('form').addEventListener('submit', function(event) {
    var password = document.getElementById('exampleInputPassword1').value;
    var passwordRepeat = document.querySelector('input[name="password_repeat"]').value;
  
    if (password !== passwordRepeat) {
      event.preventDefault();
      var errorMsg = document.createElement('p');
      errorMsg.textContent = 'Las contraseñas no coinciden';
      errorMsg.style.color = 'red';
      this.insertBefore(errorMsg, this.firstChild);
    }
  });