// Obtener el contenedor y el botón
const contenedor = document.getElementById('nuevaTarea');
const boton = document.getElementById('btn-tarea');
const botonE = document.getElementById('btn-Empezar');
var aktivo = false;
var listaNombres=[];
var listaDuracion = []; // Lista para almacenar los valores
var listaBreak=[];
var i=0;
const nombreTarea = document.getElementById('temporizador');
// Agregar un evento al botón para mostrar el contenedor y duplicar el primer contenedor
boton.addEventListener('click', () => {
    // Agregar los valores a la lista
    
    const nombre = document.getElementById('taskName');
    const campo1 = document.getElementById('taskDuration');
    const campo2=document.getElementById('breakDuration');

    listaBreak.push(campo2.value);
    listaDuracion.push(campo1.value);    
    listaNombres.push(nombre.value);
    alert("¡Tarea añadida correctamente!")
});
botonE.addEventListener('click', () => {
    Empezar()
    function Empezar(){
        if(aktivo==false){
            aktivo=true;
            // Agregar los valores a la lista
        nombreTarea.textContent=listaNombres.shift();
        const taskDuration = listaDuracion.shift();
        const countDownDate = new Date().getTime() + (taskDuration * 60 * 1000);
    
        // Actualizar el contador cada segundo
        var x = setInterval(function() {
            const now = new Date().getTime(); // Update the current time on each iteration
    
            // Calcular la diferencia entre la fecha de vencimiento y la fecha actual
            var distance = countDownDate - now;
            // Calcular los días, horas, minutos y segundos restantess
            var minutes = Math.floor(distance / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
            // Mostrar el resultado en el elemento con id="countdown"
            document.getElementById("countdown").innerHTML = minutes + "m " + seconds + "s ";
    
            // Si la cuenta regresiva ha terminado, mostrar un mensaje y comenzar el temporizador de descanso
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("countdown").innerHTML = "EXPIRED";
                startBreakTimer(); // Llamar a la función para iniciar el temporizador de descanso
                alert("¡El temporizador ha expirado! ¡Es hora de tomar un descanso!");
            }
        }, 1000);
    }

    // Función para iniciar el temporizador de descanso
    function startBreakTimer() {
        // Aquí puedes agregar el código para el temporizador de descanso
        // Por ejemplo
        const duracion = listaBreak.shift();
        const breakCountDownDate = new Date().getTime() + (duracion * 60 * 1000);

        var y = setInterval(function() {
            const now = new Date().getTime(); // Update the current time on each iteration

            // Calcular la diferencia entre la fecha de vencimiento y la fecha actual
            var distance = breakCountDownDate - now;

            // Calcular los días, horas, minutos y segundos restantes
            var minutes = Math.floor(distance / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Mostrar el resultado en el elemento con id="breakCountdown"
            document.getElementById("breakCountdown").innerHTML = minutes + "m " + seconds + "s ";

            // Si la cuenta regresiva ha terminado, mostrar un mensaje
            if (distance < 0) {
                clearInterval(y);
                document.getElementById("breakCountdown").innerHTML = "BREAK EXPIRED";
                aktivo = false;
                alert("¡Se acabo el descanso! ¡Vamos con la siguiente tarea!");
                Empezar();
            }
        }, 1000);
    }

    
    }

});
window.addEventListener('beforeunload', function (e) {
    // Cancelar el evento
    e.preventDefault();
    // Chrome requiere que se establezca returnValue
    e.returnValue = '';
});