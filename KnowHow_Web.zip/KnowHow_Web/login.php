<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Datos de conexión a la base de datos
    $host = 'localhost';
    $user = 'root';
    $password = ''; // Tu contraseña de MySQL
    $database = 'knowhow';

    // Conexión a la base de datos
    $mysqli = new mysqli($host, $user, $password, $database);

    // Verificar conexión
    if ($mysqli->connect_error) {
        die("Error de conexión: " . $mysqli->connect_error);
    }

    // Recibir datos del formulario
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Buscar el usuario en la base de datos
    $query = "SELECT * FROM usuarios WHERE email='$email'";
    $result = $mysqli->query($query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo "<script type='text/javascript'>
                alert('¡Inicio de sesion exitoso!, Bienvenido $email!');
                window.location.href = 'index.html';
                </script>";
        } else {
            echo "Contraseña incorrecta. Por favor, inténtalo de nuevo.";
        }
    } else {
        echo "Usuario no encontrado. Por favor, regístrate.";
    }

    // Cerrar conexión
    $mysqli->close();
} else {
    echo "Acceso denegado.";
}
?>
