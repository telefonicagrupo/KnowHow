<?php
// Datos de conexión a la base de datos
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'KnowHow';

// Conexión a la base de datos
$mysqli = new mysqli($host, $user, $password, $database);

// Verificar conexión
if ($mysqli->connect_error) {
    die("Error de conexión: " . $mysqli->connect_error);
}

// Recibir datos del formulario
$email = $_POST['email'];
$password = $_POST['password'];

// Consulta para verificar las credenciales
$query = "SELECT * FROM usuarios WHERE email='$email' AND password='$password'";
$result = $mysqli->query($query);

if ($result->num_rows > 0) {
    // Usuario autenticado correctamente
    echo "¡Bienvenido! Autenticación exitosa para el email: $email";
} else {
    // Usuario no encontrado o credenciales incorrectas
    echo "Error: Usuario no encontrado o credenciales incorrectas";
}

// Cerrar conexión
$mysqli->close();
?>