<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Datos de conexión a la base de datos
    $host = 'localhost';
    $user = 'root';
    $password = ''; // Tu contraseña de MySQL
    $database = 'knowhow';

    // Conexión a la base de datos
    $mysqli = new mysqli($host, $user, $password, $database);

    // Verificar conexión
    if ($mysqli->connect_error) {
        die("Error de conexión: " . $mysqli->connect_error);
    }

    // Recibir datos del formulario
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_repeat = $_POST['password_repeat'];

    // Verificar si el email ya está en uso
    $query_check_email = "SELECT * FROM usuarios WHERE email='$email'";
    $result_check_email = $mysqli->query($query_check_email);

    if ($result_check_email->num_rows > 0) {
        echo "El email ya está en uso, por favor elige otro.";
    } else {
        // Verificar si las contraseñas coinciden
        if ($password === $password_repeat) {
            // Hash de la contraseña (Para mayor seguridad)
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insertar nuevo usuario en la base de datos
            $insertQuery = "INSERT INTO usuarios (email, password) VALUES ('$email', '$hashed_password')";

            if ($mysqli->query($insertQuery) === TRUE) {
                echo "<script type='text/javascript'>
                alert('¡Registro exitoso para el email: $email!');
                window.location.href = 'index.html';
                </script>";
            } else {
                echo "Error al registrar el usuario: " . $mysqli->error;
            }
        } else {
            echo "Las contraseñas no coinciden. Por favor, inténtalo de nuevo.";
        }
    }

    // Cerrar conexión
    $mysqli->close();
} else {
    echo "Acceso denegado.";
}
?>
